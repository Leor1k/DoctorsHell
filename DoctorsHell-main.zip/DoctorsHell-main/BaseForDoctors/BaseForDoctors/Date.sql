﻿CREATE TABLE [dbo].[Date]
(
	[DateId] INT NOT NULL PRIMARY KEY, 
    [Date] DATE NOT NULL, 
    [StartWork] TIME NOT NULL, 
    [EndWork] TIME NOT NULL
)
