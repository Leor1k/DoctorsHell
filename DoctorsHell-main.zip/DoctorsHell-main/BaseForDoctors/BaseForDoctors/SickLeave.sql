﻿CREATE TABLE [dbo].[SickLeave]
(
	[SickLeaveId] INT NOT NULL PRIMARY KEY, 
    [DateStart] DATE NOT NULL, 
    [DateEnd] DATE NOT NULL
)
