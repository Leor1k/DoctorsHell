﻿CREATE TABLE [dbo].[Status]
(
	[StatusId] INT NOT NULL PRIMARY KEY, 
    [Status] NCHAR(10) NOT NULL
)
