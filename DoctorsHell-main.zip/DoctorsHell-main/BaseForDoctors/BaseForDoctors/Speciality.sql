﻿CREATE TABLE [dbo].[Speciality]
(
	[SpecialityId] INT NOT NULL PRIMARY KEY, 
    [Speciality] NCHAR(30) NOT NULL
)
