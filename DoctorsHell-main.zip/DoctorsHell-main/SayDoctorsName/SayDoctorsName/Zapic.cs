﻿using System;

namespace SayDoctorsName
{
    public class Zapic
    {
        public int Appointmet { get; set; }
        public string PatientName { get; set; }
        public string PatientLastName { get; set; }
        public string PatientSecondName { get; set; }
        public DateTime DateTimeAppoiment { get; set; }
        public string Health { get;set; } 
    }
}
